setwd("/Users/Apple/Desktop/MSc in data science/2021 courses/Machine Learning/Projects & Exercises/Exercise 1/Classification/cust_segmentation/")

############################################
# 1. Read data & Exploratory data analysis
###########################################

library(tidyverse)
library(ggplot2)
library(tidyr)
library(plyr)
library(dplyr)

train.data<- read.csv("Train.csv",header = TRUE,sep = ",")

sample.sub<- read.csv("sample_submission.csv",header = TRUE,sep = ",")


# check for the missing values (NA or empty values) in dataset

training.missing<- apply(train.data,2,function(x) sum(is.na(x)|x==""))
training.missing
# No duplicates data in the dataset i.e. no need to remove
# remove the ID column since it has no effect in classification and they are all unique

train.data<- train.data[,-1]


#-----------------------------
#V1:Gender:no missing values
#-----------------------------

gender.plot<- ggplot(train.data,aes(x=Gender))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
gender.plot

#--------------------------------------------------------------------------
#V2:Marital status :140 null/missing values, no pattern for missing values
#---------------------------------------------------------------------------

train.data %>% filter(Ever_Married=="No" & (Spending_Score %in% c("Average","High","Low"))) %>% group_by(Spending_Score) %>% dplyr::summarise(total=n())
train.data %>% filter(Ever_Married=="Yes" & (Spending_Score %in% c("Average","High","Low"))) %>% group_by(Spending_Score) %>% dplyr::summarise(total=n())
train.data[which(train.data$Ever_Married=="" & train.data$Spending_Score %in% c("Average","High")),]$Ever_Married <-"Yes"

train.data %>% filter(Ever_Married=="No") %>% group_by(Age) %>% dplyr::summarise(total=n())
train.data %>% filter(Ever_Married=="Yes") %>% group_by(Age) %>% dplyr::summarise(total=n())
train.data[which(train.data$Ever_Married=="" & train.data$Age>43),]$Ever_Married <-"Yes"
train.data[which(train.data$Ever_Married=="" & train.data$Spending_Score=="Low"),]$Ever_Married <-"No"


marital.plot<- ggplot(train.data,aes(x=Ever_Married))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
marital.plot
train.data %>% group_by(Segmentation,Ever_Married) %>% dplyr::summarise(count=n())
#at most segment C is married and segment D are mostly single


#-------------------------------
#V3:Age: No null/missing values
#-------------------------------
age.plot<- ggplot(train.data,aes(x=as.factor(Segmentation),y=Age))+geom_boxplot()
age.plot


#make a grouping in age variable based on percentiles:

train.data<-train.data %>%  mutate(Age.group=case_when(Age>=18 & Age<=35 ~ "18-35",
                                                       Age>35 & Age<=45 ~ "16-45",
                                                       Age>45 & Age<=60 ~ "46-60",
                                                       Age>60~ "60+"))

age.plot2<- ggplot(train.data,aes(x=Age.group))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
age.plot2


#--------------------------------------
#V4:Graduated: 78 null/missing values
#--------------------------------------

# fill in missing values with  the most possible values based on existing patterns
train.data[which(train.data$Graduated=="" & train.data$Age>=45),]$Graduated <-"Yes"
train.data[which(train.data$Graduated=="" & train.data$Ever_Married=="Yes"),]$Graduated <-"Yes"
train.data[which(train.data$Graduated=="" & train.data$Var_1=="Cat_6"),]$Graduated <-"Yes"

train.data[which(train.data$Graduated==""),]$Graduated <-"Yes" #correct later on with prev value

graduate.plot<- ggplot(train.data,aes(x=Graduated))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
graduate.plot


#--------------------------------------
#V5: Profession:124 null/missing values
#--------------------------------------

train.data[which(train.data$Profession=="" & train.data$Graduated=="Yes"),]$Profession <-"Artist"
train.data[which(train.data$Profession=="" & train.data$Ever_Married=="No"),]$Profession <-"Healthcare"
train.data[which(train.data$Profession=="" & train.data$Spending_Score=="High"),]$Profession <-"Executive"
train.data[which(train.data$Profession=="" & train.data$Age>60),]$Profession <-"Lawyer"
train.data[which(train.data$Profession==""),]$Profession <-"Artist"

prof.plot<- ggplot(train.data,aes(x=Profession))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
prof.plot

#-------------------------------------------
#V6: Work experience:829 null/missing values   # check the relation with age, spending score add correlation
#-------------------------------------------

#fill missing values with previous value

train.data<-train.data %>% fill(Work_Experience)
work.exp.plot<- ggplot(train.data,aes(x=as.factor(Segmentation),y=Work_Experience))+geom_boxplot()
work.exp.plot  #segment D includes most experienced people
quantile(train.data$Work_Experience)

train.data<-train.data %>%  mutate(Experience.group=case_when(Work_Experience<=1 ~ "Low experience",
                                                              Work_Experience>1 & Work_Experience<=7 ~ "Medium experience",
                                                              Work_Experience>7 ~ "High Experience"))
work.exp.plot2<- ggplot(train.data,aes(x=Experience.group))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
work.exp.plot2    

#-------------------------------------------
#V7: Spending score:0 null values
#-------------------------------------------
spending.plot<- ggplot(train.data,aes(x=Spending_Score))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
spending.plot  # segment D has the lowest rate of spending

#-------------------------------------------
#V8: Var_1 :76 null values
#-------------------------------------------
train.data[which(train.data$Var_1=="" & train.data$Graduated=="Yes"),]$Var_1 <-"Cat_6"
train.data[which(train.data$Var_1=="" & train.data$Graduated=="No"),]$Var_1 <-"Cat_4"
var1.plot<- ggplot(train.data,aes(x=Var_1))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
var1.plot


#-------------------------------------------
#V8: Family Size :335 null values
#-------------------------------------------

quantile(train.data$Family_Size,na.rm = TRUE)


train.data<- train.data %>%  fill(Family_Size)
family.size.plot<- ggplot(train.data,aes(x=as.factor(Segmentation),y=Family_Size))+geom_boxplot()
family.size.plot

#make a grouping in family size variable based on percentiles:

train.data<-train.data %>%  mutate(Family.size.group=case_when(Family_Size>0 & Family_Size<=4 ~ "Small",
                                                               Family_Size>4 & Family_Size<=6 ~ "Medium",
                                                               Family_Size>6  ~ "Big"))

family.size.plot2<- ggplot(train.data,aes(x=Family.size.group))+geom_bar(aes(fill=as.factor(Segmentation)),position="dodge")
family.size.plot2


# segmentation analysis

ggplot(train.data,aes(x=Segmentation)) + geom_bar()

training.missing<- apply(train.data,2,function(x) sum(is.na(x)|x==""))
training.missing

summary(train.data)

#remove the age, work experience and family size columns since these variables are grouped and new variables are created.
train.data<- train.data[,-c(3,6,8)]



write_csv(train.data,"training_data.csv")



# CLEAN TEST DATA
test.data<- read.csv("Test.csv",header = TRUE,sep = ",")
test.missing<- apply(test.data,2,function(x) sum(is.na(x)|x==""))
test.missing

#-----------------------------
#V1:Gender:no missing values
#--------------------------------------------------------------------------
#V2:Marital status :50 null/missing values, no pattern for missing values
#---------------------------------------------------------------------------

test.data %>% filter(Ever_Married=="No" & (Spending_Score %in% c("Average","High","Low"))) %>% group_by(Spending_Score) %>% dplyr::summarise(total=n())
train.data %>% filter(Ever_Married=="Yes" & (Spending_Score %in% c("Average","High","Low"))) %>% group_by(Spending_Score) %>% dplyr::summarise(total=n())
test.data[which(test.data$Ever_Married=="" & test.data$Spending_Score=="Low"),]$Ever_Married <-"No"

test.data %>% filter(Ever_Married=="No") %>% group_by(Age) %>% dplyr::summarise(total=n())
test.data %>% filter(Ever_Married=="Yes") %>% group_by(Age) %>% dplyr::summarise(total=n())
test.data[which(test.data$Ever_Married=="" & test.data$Age>40),]$Ever_Married <-"Yes"
test.data[which(test.data$Ever_Married==""),]$Ever_Married <-"Yes"


#-------------------------------
#V3:Age: No null/missing values

test.data<-test.data %>%  mutate(Age.group=case_when(Age>=18 & Age<=35 ~ "18-35",
                                                     Age>35 & Age<=45 ~ "16-45",
                                                     Age>45 & Age<=60 ~ "46-60",
                                                     Age>60~ "60+"))


#--------------------------------------
#V4:Graduated: 24 null/missing values
#--------------------------------------

# fill in missing values with  the most possible values based on existing patterns
test.data[which(test.data$Graduated=="" & test.data$Age>=45),]$Graduated <-"Yes"
test.data[which(test.data$Graduated=="" & test.data$Ever_Married=="Yes"),]$Graduated <-"Yes"
test.data[which(test.data$Graduated=="" & test.data$Var_1=="Cat_6"),]$Graduated <-"Yes"
test.data[which(test.data$Graduated==""),]$Graduated <-"Yes"


#--------------------------------------
#V5: Profession:38 null/missing values
#--------------------------------------

test.data[which(test.data$Profession=="" & test.data$Graduated=="Yes"),]$Profession <-"Artist"
test.data[which(test.data$Profession=="" & test.data$Ever_Married=="No"),]$Profession <-"Healthcare"
test.data[which(test.data$Profession=="" & test.data$Spending_Score=="High"),]$Profession <-"Executive"
test.data[which(test.data$Profession=="" & test.data$Age>60),]$Profession <-"Lawyer"
test.data[which(test.data$Profession==""),]$Profession <-"Artist"



#-------------------------------------------
#V6: Work experience:829 null/missing values   # check the relation with age, spending score add correlation
#-------------------------------------------

#fill missing values with previous value

test.data<-test.data %>% fill(Work_Experience)
quantile(test.data$Work_Experience)

test.data<-test.data %>%  mutate(Experience.group=case_when(Work_Experience<=1 ~ "Low experience",
                                                            Work_Experience>1 & Work_Experience<=7 ~ "Medium experience",
                                                            Work_Experience>7 ~ "High Experience"))


#-------------------------------------------
#V7: Spending score:0 null values

#-------------------------------------------
#V8: Var_1 :76 null values
#-------------------------------------------
test.data[which(test.data$Var_1=="" & test.data$Graduated=="Yes"),]$Var_1 <-"Cat_6"
test.data[which(test.data$Var_1=="" & test.data$Graduated=="No"),]$Var_1 <-"Cat_4"


#-------------------------------------------
#V8: Family Size :335 null values
#-------------------------------------------


test.data<- test.data %>%  fill(Family_Size)

#make a grouping in family size variable based on percentiles:

test.data<-test.data %>%  mutate(Family.size.group=case_when(Family_Size>0 & Family_Size<=4 ~ "Small",
                                                             Family_Size>4 & Family_Size<=6 ~ "Medium",
                                                             Family_Size>6  ~ "Big"))


# segmentation analysis


test.missing<- apply(test.data,2,function(x) sum(is.na(x)|x==""))
test.missing

summary(test.data)

#remove the age, work experience and family size columns since these variables are grouped and new variables are created.
test.data<- test.data[,-c(3,6,8)]



####################################
# MODELING
###################################

library(tidyverse)
library(class)
library(caret)
library(ggplot2)
library(rpart)
library(partykit)
library(randomForest)
library(e1071)
library("nnet")
library("keras")


# 1. DECISION TREE

# 1. train and test data split

train.data$Age.group<- as.factor(train.data$Age.group)
train.data$Experience.group<- as.factor(train.data$Experience.group)
train.data$Family.size.group<- as.factor(train.data$Family.size.group)

set.seed(12345)
smp_size <- floor(0.75 * nrow(train.data))
train_ind <- sample(seq_len(nrow(train.data)), size = smp_size)
train <- train.data[train_ind,]
test <- train.data[-train_ind,]

# Tuning

## Validation Set

tunobj_rpart = tune.rpart(Segmentation ~., data = train, cp = c(0.002,0.005,0.01,0.015,0.02,0.03),
                          tunecontrol =  tune.control(nrepeat = 5))
tunobj_rpart$best.model

# the best cp for decision tree is 0.002

plot(tunobj_rpart,main="Tune rpart on Complexity Parameter")


#model performance

pred_rpart = predict(tunobj_rpart$best.model, test,type="class")
matrix_rpart = confusionMatrix(pred_rpart,test$Segmentation,mode = "prec_recall")
matrix_rpart

# 52.06% accuracy

# 2. RANDOM FOREST


tunobj_randomForest = tune.randomForest(Segmentation ~., data = train, 
                                        ntree = c(300,400,500,600),
                                        tunecontrol =  tune.control(nrepeat = 5))
tunobj_randomForest$best.model


# 600 ntree is optimal

plot(tunobj_randomForest)


#model performance
pred_randomforest = predict(tunobj_randomForest$best.model, test,type="class")
confusionMatrix(pred_randomforest,test$Segmentation,mode = "prec_recall")

#52.65% accuracy


# 3. KNN

#convert all categorical variable except dependent one to numeric for KNN
train$Gender<-unclass(train$Gender)
train$Ever_Married<-unclass(train$Ever_Married)
train$Graduated<-unclass(train$Graduated)
train$Profession<-unclass(train$Profession)
train$Spending_Score<-unclass(train$Spending_Score)
train$Var_1<-unclass(train$Var_1)
train$Age.group<-unclass(train$Age.group)
train$Experience.group<-unclass(train$Experience.group)
train$Family.size.group<-unclass(train$Family.size.group)



test$Gender<-unclass(test$Gender)
test$Ever_Married<-unclass(test$Ever_Married)
test$Graduated<-unclass(test$Graduated)
test$Profession<-unclass(test$Profession)
test$Spending_Score<-unclass(test$Spending_Score)
test$Var_1<-unclass(test$Var_1)
test$Age.group<-unclass(test$Age.group)
test$Experience.group<-unclass(test$Experience.group)
test$Family.size.group<-unclass(test$Family.size.group)




tunobj_knn = tune.knn(train[-7], train$Segmentation,
                      k = 1 : 10,
                      tunecontrol =  tune.control(nrepeat = 5))

tunobj_knn$best.model

plot(tunobj_knn)

#model performance

train2 <- train[complete.cases(train),]
test2 <- test[complete.cases(test),]
testX <- test2[,-7]
trainX <- train2[,-7]
topredict <- train2$Segmentation

pred_knn = knn(trainX, testX, topredict, k = 9)
confusionMatrix(pred_knn,test$Segmentation,mode = "prec_recall")

#accuracy is 0.513
# so the best model is Random forest with a slightly higher accuracy %52.65
